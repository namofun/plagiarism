﻿using System;

namespace Problem_1
{
    public enum Suit
    {
        Clubs,
        Diamonds,
        Hearts,
        Spades,
    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Card Suits:");
            foreach (var t in Enum.GetValues(typeof(Suit)))
            {
                Console.WriteLine("Ordinal value:{0}; Name value:{1}", (int)t, t.ToString());
            }
        }
    }
}
