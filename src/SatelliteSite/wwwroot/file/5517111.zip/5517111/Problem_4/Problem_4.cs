﻿using System;
using System.Collections.Generic;

namespace _55171112
{
    class Problem_4
    {
        /*  附上doc上的测试数据:
         *  JLU CCST
         *  Did you know Math.Round rounds to the nearest even integer?
         */
        static void Main(string[] args)
        {
            while (true)
            {
                Console.Write("Input:");
                string s = Console.ReadLine();
                Count(s);
            }
        }

        static void Count(string s)
        {
            SortedDictionary<char,int> dic = new SortedDictionary<char,int>();
            foreach(var i in s)
            {
                if (!dic.ContainsKey(i))
                    dic.Add(i, 1);
                else
                    dic[i]++;
            }
            foreach(var i in dic)
            {
                Console.WriteLine("{0}: {1} time/s", i.Key, i.Value);
            }
        }
    }
}
