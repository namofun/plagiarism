﻿using System;
using System.Collections.Generic;

namespace _55171112
{
    class Problem_3
    {
        // 此题输入较为复杂，故只能用户输入了。。。
        // ♥同学辛苦了♥
        /*--附上doc上的测试数据--*/
        /*  Input
            4
            Ce O
            Mo O Ce
            Ee
            Mo
        */              //Output: Ce Ee Mo O
        /*  Input
            3
            Ge Ch O Ne
            Nb Mo Tc
            O Ne
        */              // Output: Ch Ge Mo Nb Ne O Tc
        static void Main(string[] args)
        {
            while(true)
            {
                F();
            }
        }
        static void F()
        {
            int n;
            n = Int32.Parse(Console.ReadLine());
            SortedSet<string> set = new SortedSet<string>();
            for (int i = 0;i<n;i++)
            {
                string[] t = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries);
                foreach(var x in t)
                {
                    set.Add(x);
                }
            }
            foreach(var i in set)
            {
                Console.Write("{0} ", i);
            }
            Console.WriteLine();
        }
    }
}
