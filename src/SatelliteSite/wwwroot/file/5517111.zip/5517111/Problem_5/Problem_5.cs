﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace _55171112
{
    class Problem_5
    {
        static void Main(string[] args)
        {
            string path = Directory.GetCurrentDirectory();
            string words = File.ReadAllText(path.Split("bin", StringSplitOptions.RemoveEmptyEntries)[0]+"words.txt");
            Dictionary<string, int> dic = new Dictionary<string, int>();
            foreach (string i in words.ToLower().Split(" ", StringSplitOptions.RemoveEmptyEntries))
            {
                dic.Add(i, 0);
            };
            string text = File.ReadAllText(path.Split("bin", StringSplitOptions.RemoveEmptyEntries)[0] + "text.txt");
            foreach (string i in text.ToLower().Split(new char[] { '-', ' ', ',', '.', '?', '!' }, StringSplitOptions.RemoveEmptyEntries))
            {
                if (dic.ContainsKey(i))
                    dic[i]++;
            };
            var res = from d in dic
                      orderby d.Value
                      descending
                      select d;
            List<string> rs = new List<string>();
            foreach (var i in res)
            {
                rs.Add(i.Key + " - " + i.Value);
            }
            File.WriteAllLines(path.Split("bin", StringSplitOptions.RemoveEmptyEntries)[0] + "results.txt", rs.ToArray());
        }
    }
}
