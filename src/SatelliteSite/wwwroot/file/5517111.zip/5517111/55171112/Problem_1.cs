﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace _55171112
{
    class Problem_1
    {
        static void Main(string[] args)
        {
            S(2);
            S(-1);
            S(1000);
        }
        static void S(int n)
        {
            Console.Write("N={0} | ", n);
            Queue<int> q = new Queue<int>();
            q.Enqueue(n);
            int i = 0;
            while(i<50)
            {
                Console.Write("{0} ", q.Peek());i++;
                int k = q.Dequeue();
                q.Enqueue(k + 1);
                q.Enqueue(2 * k + 1);
                q.Enqueue(k + 2);
            }
            Console.WriteLine();
        }
    }
}
