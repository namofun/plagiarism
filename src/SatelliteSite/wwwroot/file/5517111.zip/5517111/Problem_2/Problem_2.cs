﻿using System;
using System.Collections.Generic;

namespace _55171112
{
    class Problem_2
    {
        static void Main(string[] args)
        {
            F("{[()]}");
            F("{[(])}");
            F("{{[[(())]]}}");
        }
        static void F(string s)
        {
            Console.WriteLine("{0} : {1}",s, DeBalance(s) ? "YES" : "NO");
        }
        static bool DeBalance(string str)
        {
            Stack<char> s = new Stack<char>();
            foreach(var i in str)
            {
                if (i == '[' || i == '{' || i == '(')
                {
                    s.Push(i);
                }
                else if (i == ']' || i == '}' || i == ')')
                {
                    char t = i switch
                    {
                        ']' => '[',
                        '}' => '{',
                        ')' => '(',
                        _ => ' ',
                    };
                    if (s.Peek() == t)
                    {
                        s.Pop();
                    }
                    else
                        return false;
                }
                else
                    return false;
            }
            if (s.Count == 0)
                return true;
            else
                return false;
        }
    }
}
