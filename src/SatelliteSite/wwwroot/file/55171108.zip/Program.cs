﻿using System;

namespace Problem1
{
    public enum Suits
    {
        Clubs,Diamonds,Hearts,Spades
    }
    class Program
    {
        static void Main(string[] args)
        {
            var AllSuits = Enum.GetValues(typeof(Suits));
            Console.WriteLine("Card Suits:");
            foreach(var a in AllSuits)
            {
                Console.WriteLine("Ordinal Value: {0},Name Value: {1}", (int)a, a.ToString());
            }
        }
    }
}
